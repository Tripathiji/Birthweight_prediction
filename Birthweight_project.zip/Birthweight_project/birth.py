# -*- coding: utf-8 -*-
"""
Created on Fri Mar  1 15:42:01 2019

@author: adhis
"""

# Loading Libraries
import pandas as pd
import statsmodels.formula.api as smf # regression modeling
import seaborn as sns
import matplotlib.pyplot as plt


file = 'birthweight.xlsx'

birthweight = pd.read_excel(file)

########################
# Fundamental Dataset Exploration
########################

# Column names
birthweight.columns


# Displaying the first rows of the DataFrame
print(birthweight.head())


# Dimensions of the DataFrame
birthweight.shape


# Information about each variable
birthweight.info()


# Descriptive statistics
birthweight.describe().round(2)


birthweight.sort_values('SalePrice', ascending = False)

birthweight.plot
plt.show()
